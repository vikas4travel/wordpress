=== WP Custome Post ===
Contributors: vikas sharma
Tags: wp custom post
Tested up to: 0.1
Stable tag: 0.1
Requires at least: 3.0

A Custome Post Type Plugin.

== Description ==

1) Custom Post Type Widget
2) Custom Taxonomy Widget
3) Comment Widget

== Installation ==

1) Extract WP-Custom-Post.zip
2) Go to /wp-content/plugins/ and upload the extracted files.
3) Activate the plugin through the 'Plugins' menu in WordPress.
4) Go to Dashboard -> Custom Post Type and create new custom posts.
