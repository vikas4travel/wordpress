=== WP Custome Taxonomy ===
Contributors: vikas sharma
Tags: wp custom taxonomy 
Tested up to: 0.1
Stable tag: 0.1
Requires at least: 3.0

A Custome Taxonomy Plugin.

== Description ==

Custom Taxonomy Widget

== Installation ==

1) Extract WP-Custom-Taxonomy.zip
2) Go to /wp-content/plugins/ and upload the extracted files.
3) Activate the plugin through the 'Plugins' menu in WordPress.

